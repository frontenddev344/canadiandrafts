export const AboutData = [
    {
        text: "We are a passionate team of travel enthusiasts dedicated to showcasing the best that Canada has to offer. Our mission is to provide you with a comprehensive resource that helps you discover the finest accommodations, attractions, dining experiences, and more across the breathtaking landscapes of Canada."
    },
    
]