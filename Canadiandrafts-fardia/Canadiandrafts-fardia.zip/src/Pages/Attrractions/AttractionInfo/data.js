export const AttractionData = [
    {
        text: "Discover the most captivating attractions across Canada. From breathtaking natural wonders to vibrant cultural landmarks, we have curated a list of the country's best attractions that will ignite your sense of adventure and leave you in awe of Canada's beauty and diversity."
    },
    
]