import styled from "styled-components";
export const AttractionInfotext = styled.section`

`;