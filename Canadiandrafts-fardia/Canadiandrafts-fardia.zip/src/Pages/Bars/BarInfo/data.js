export const BartopData = [
    {
        text: "Welcome to CanadianDrafts, your ultimate guide to the best sports bars across Canada. We understand the excitement of cheering on your favorite teams while enjoying great food, drinks, and the electric atmosphere of a sports bar. That's why we have handpicked the finest establishments in the country that offer the perfect blend of sports entertainment, camaraderie, and hospitality."
    },
    
]