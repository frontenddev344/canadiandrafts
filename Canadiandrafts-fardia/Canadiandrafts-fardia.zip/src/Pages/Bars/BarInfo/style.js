import styled from "styled-components";
export const BarInfotext = styled.section`

`;