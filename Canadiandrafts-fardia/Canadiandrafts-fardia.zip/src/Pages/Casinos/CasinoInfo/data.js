export const CasintopData = [
    {
        text: "CanadianDrafts is your ultimate guide to the most thrilling and luxurious casinos across Canada. Whether you're a seasoned gambler seeking the adrenaline rush of the gaming floor or a leisurely player looking to enjoy world-class entertainment, we have handpicked the best casinos in the country to ensure an unforgettable experience."
    },
    
]