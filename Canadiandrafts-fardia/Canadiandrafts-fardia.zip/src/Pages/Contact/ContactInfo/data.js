export const ContactData = [
    {
        text: "We value your feedback and are always eager to assist you with any inquiries or suggestions you may have. Feel free to reach out to us using the contact information provided below. We'll make every effort to respond to your message promptly."
    },
    
]