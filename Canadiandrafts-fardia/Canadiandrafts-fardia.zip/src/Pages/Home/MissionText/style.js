import styled from "styled-components";
export const MissionMain = styled.section`
    padding:70px 0;
    text-align:left;
    .img-rght {
        height: 100%;
        img{
            height:100%;
            object-fit:cover;
        }
    }
`;