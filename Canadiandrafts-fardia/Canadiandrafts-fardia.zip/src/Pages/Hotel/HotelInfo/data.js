export const TopData = [
    {
        text: "CanadianDrafts is  your premier source for discovering the finest hotels across Canada. As avid travelers ourselves, we understand the importance of finding exceptional accommodations that elevate your journey and create lasting memories. That's why we have curated a list of the best hotels in Canada, each offering a unique blend of comfort, style, and impeccable service."
    },
    
]