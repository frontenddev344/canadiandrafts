import styled from "styled-components";
export const InfoText = styled.section`

`;