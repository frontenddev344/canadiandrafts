export const PrivacyData = [
    {
        text: "At canadiandrafts, accessible from canadiandrafts.com, one of our main priorities is the privacy of our visitors. This Privacy Policy document contains types of information that is collected and recorded by canadiandrafts and how we use it."
    },
    
]