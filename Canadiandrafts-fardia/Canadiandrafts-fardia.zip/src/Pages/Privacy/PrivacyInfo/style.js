import styled from "styled-components";
export const PrivacyText = styled.section`

`;