import { Header } from '../Header';
import { Footer } from '../Footer';
export const Restaurents = () => {
    return(
        <>
        <Header/>
        <Footer/>
        </>
    );
};