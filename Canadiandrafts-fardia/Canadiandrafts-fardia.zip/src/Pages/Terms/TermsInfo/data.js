export const TermsData = [
    {
        text: "These terms and conditions outline the rules and regulations for the use of canadiandrafts's Website, located at canadiandrafts.com."
    },
    
]