import styled from "styled-components";
export const TermsText = styled.section`

`;