import styled from "styled-components";
export const ExtranalInfo = styled.div`
    .Infotext {
        margin-bottom: 20px;
    }
    @media screen and (max-width:899px){
        text-align:center;
    }
`;
