export const AboutData = [
    {
        text:"Nous sommes une équipe passionnée de passionnés de voyages dédiés à mettre en valeur le meilleur que le Canada a à offrir. Notre mission est de vous fournir une ressource complète qui vous aide à découvrir les meilleurs hébergements, attractions, expériences culinaires et plus encore à travers les paysages à couper le souffle du Canada."
    },
    
]