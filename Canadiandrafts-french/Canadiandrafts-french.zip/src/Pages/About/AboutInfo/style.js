import styled from "styled-components";
export const AboutInfotext = styled.section`

`;