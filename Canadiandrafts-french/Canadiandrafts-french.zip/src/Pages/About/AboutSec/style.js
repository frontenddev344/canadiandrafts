import styled from "styled-components";
export const AboutSecMain = styled.section`
    padding:70px 0;
    .AbtRgt {
        align-items: center;
        .textLft {
            p {
                 margin-bottom: 30px;
                text-align: justify;
            }
        }
    }
`;