export const AttractionData = [
    {
        text:"Découvrez les attractions les plus captivantes du Canada. Des merveilles naturelles à couper le souffle aux sites culturels dynamiques, nous avons dressé une liste des meilleures attractions du pays qui enflammeront votre sens de l'aventure et vous laisseront émerveillés par la beauté et la diversité du Canada.",
    },
    
]