import styled from "styled-components";
export const LastinfoMain = styled.section`
    padding: 70px 0px;
    background: rgb(255, 254, 246);
    .AllInfo {
        text-align: center;
    }
`;