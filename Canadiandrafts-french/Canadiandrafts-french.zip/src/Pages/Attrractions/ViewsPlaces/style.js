import styled from "styled-components";
export const ViewsPlacesMain = styled.section`
    padding:30px 0;
`;