export const BartopData = [
    {
        text:"Bienvenue sur CanadianDrafts, votre guide ultime des meilleurs bars sportifs à travers le Canada. Nous comprenons l'excitation d'encourager vos équipes préférées tout en profitant de la bonne nourriture, des boissons et de l'atmosphère électrique d'un bar sportif. C'est pourquoi nous avons sélectionné les meilleurs établissements du pays qui offrent le mélange parfait de divertissement sportif, de camaraderie et d'hospitalité."
    },
    
]