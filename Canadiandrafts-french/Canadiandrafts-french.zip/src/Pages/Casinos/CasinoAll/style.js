import styled from "styled-components";
export const CasinoAllmain = styled.section`
    padding:70px 0;
   
`;