export const CasintopData = [
    {
        text:"CanadianDrafts est votre guide ultime des casinos les plus excitants et les plus luxueux du Canada. Que vous soyez un joueur chevronné à la recherche de la poussée d'adrénaline de la salle de jeu ou un joueur tranquille cherchant à profiter d'un divertissement de classe mondiale, nous avons sélectionné les meilleurs casinos du pays pour vous garantir une expérience inoubliable."
    },
    
]