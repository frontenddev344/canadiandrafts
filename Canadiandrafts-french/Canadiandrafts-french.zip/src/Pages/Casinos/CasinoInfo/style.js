import styled from "styled-components";
export const CasinoText = styled.section`

`;