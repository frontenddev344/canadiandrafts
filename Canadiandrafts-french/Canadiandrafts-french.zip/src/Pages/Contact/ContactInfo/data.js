export const ContactData = [
    {
        text:"Nous apprécions vos commentaires et sommes toujours prêts à vous aider pour toute question ou suggestion que vous pourriez avoir. N'hésitez pas à nous contacter en utilisant les coordonnées fournies ci-dessous. Nous ferons tout notre possible pour répondre rapidement à votre message."
    },
    
]