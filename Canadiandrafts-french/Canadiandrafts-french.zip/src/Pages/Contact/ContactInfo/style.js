import styled from "styled-components";
export const ContactText = styled.section`

`;