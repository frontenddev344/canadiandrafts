export const TopData = [
    {
        text:"CanadianDrafts est votre première source pour découvrir les meilleurs hôtels à travers le Canada. En tant que voyageurs passionnés nous-mêmes, nous comprenons l'importance de trouver des hébergements exceptionnels qui rehaussent votre voyage et créent des souvenirs durables. C'est pourquoi nous avons dressé une liste des meilleurs hôtels au Canada, chacun offrant un mélange unique de confort, de style et de service impeccable."
    },
    
]