import styled from "styled-components";
export const HotelAllmain = styled.section`
    padding:70px 0;
   
`;