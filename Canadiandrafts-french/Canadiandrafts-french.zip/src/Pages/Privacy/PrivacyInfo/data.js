export const PrivacyData = [
    {
        text:"Chez canadiandrafts, accessible à partir de canadiandrafts.com, l'une de nos principales priorités est la confidentialité de nos visiteurs. Ce document de politique de confidentialité contient des types d'informations qui sont collectées et enregistrées par canadiandrafts et comment nous les utilisons.Si vous avez des questions supplémentaires ou souhaitez plus d'informations sur notre politique de confidentialité, n'hésitez pas à nous contacter."
    },
    
]