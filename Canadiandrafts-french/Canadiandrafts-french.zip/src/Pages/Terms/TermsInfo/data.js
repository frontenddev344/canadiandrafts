export const TermsData = [
    {
        text:"Ces termes et conditions décrivent les règles et règlements pour l'utilisation du site Web de canadiandrafts, situé à canadiandrafts.com"
    },
    
]